class PopularBook {
  String name;
  String iconPath;
  bool boxIsSelected;

  PopularBook({
    required this.name,
    required this.iconPath,
    required this.boxIsSelected
  });

  static List < PopularBook > getPopularbook() {
    List < PopularBook> popularbook = [];

    popularbook.add(
      PopularBook(
       name: 'Body memory',
       iconPath: 'assets/icons/book.svg',
       boxIsSelected: true,
      )
    );

    popularbook.add(
      PopularBook(
       name: 'war and peace',
       iconPath: 'assets/icons/book3.svg',
       boxIsSelected: false,
      )
    );

    return popularbook;
  }
}