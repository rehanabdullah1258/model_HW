import 'package:flutter/material.dart';

class electronic_books {
  String name;
  String iconPath;
  String subtitle;
  Color boxColor;
  bool viewIsSelected;

  electronic_books({
    required this.name,
    required this.iconPath,
    required this.subtitle,
    required this.boxColor,
    required this.viewIsSelected
  });

  static List < electronic_books > getBook() {
    List < electronic_books > book = [];

    book.add(
        electronic_books(
       name: 'The little prince',
          subtitle: 'Antoine de Saint-Exupéry',
       iconPath: 'assets/icons/book.svg',

       viewIsSelected: true,
       boxColor: Color(0xffc8a17e)
      )
    );

    book.add(
        electronic_books(
       name: 'Harry Potter',
       iconPath: 'assets/icons/book3.svg',
          subtitle: 'Rowling',

          viewIsSelected: true,
       boxColor: Color(0xffe9967a)
      )
    );
    book.add(
        electronic_books(
            name: 'Alphabet crimes',
            iconPath: 'assets/icons/book1.svg',
            subtitle: 'Agatha Christie',

            viewIsSelected: false,
            boxColor: Color(0xffb08260)
        )
    );

    return book;
  }
}