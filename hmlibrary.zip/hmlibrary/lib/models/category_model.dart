import 'package:flutter/material.dart';

class CategoryModel {
  String name;
  String subtitle;
  Color boxColor;

  CategoryModel({
    required this.name,
    required this.subtitle,
    required this.boxColor,
  });
  
  static List<CategoryModel> getCategories() {
    List<CategoryModel> categories = [];
    
    categories.add(
      CategoryModel(
        name: 'action',
         subtitle: '42 novel',
          boxColor: Color(0xffebd0bd)
      )
    );

    categories.add(
      CategoryModel(
        name: 'imaginary',
          subtitle: '40 novel',
          boxColor: Color(0xff886953)
      )
    );

    categories.add(
      CategoryModel(
        name: 'Historic',
          subtitle: '32 novel',
          boxColor: const Color(0xfff2dfd3)
      )
    );

    categories.add(
      CategoryModel(
        name: 'Police',
          subtitle: '23 novel',
          boxColor: const Color(0xff644e3f)
      )
    );
    categories.add(
        CategoryModel(
            name: 'Emotional',
            subtitle: '35 novel',
            boxColor: const Color(0xffad8569)
        )
    );
    

    return categories;
  }
}